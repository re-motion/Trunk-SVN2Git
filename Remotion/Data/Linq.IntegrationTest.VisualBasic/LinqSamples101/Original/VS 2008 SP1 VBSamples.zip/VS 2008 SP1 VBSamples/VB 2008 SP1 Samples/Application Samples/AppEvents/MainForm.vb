﻿' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class MainForm

    Private Sub exitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class
